/** An OkHttp interceptor which logs HTTP request and response data. */
@javax.annotation.ParametersAreNonnullByDefault
package okhttp3.logging;
